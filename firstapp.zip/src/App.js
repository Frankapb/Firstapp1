import React from 'react'
import Header from './components/header'
import SliderComponent from './components/sliderComponent'
import Cards from './components/card'
import Footer from './components/footer'
import { CardDeck } from 'react-bootstrap'
import Tables from './components/tables'

function App() {
  return (
    <div>
     
      <Header/>

     <SliderComponent/>
     
     <CardDeck>
     <Cards image="https://picsum.photos/401"/>
     <Cards image="https://picsum.photos/402"/>
     <Cards image="https://picsum.photos/403"/>
     <Cards image="https://picsum.photos/400"/>
     <Cards image="https://picsum.photos/404"/>
     </CardDeck>

     <Tables/>

     <Footer/>
      
    </div>
  )
}

export default App
