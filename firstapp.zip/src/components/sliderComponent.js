import React from 'react'
import {Carousel} from 'react-bootstrap'
import './sliderComponent.css'


function SliderComponent() {
    return (
        <div>
        <Carousel>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://wallpaperaccess.com/full/44849.jpg"
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>Spiderman</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://images.hdqwalls.com/download/1/2019-captain-america-mjolnir-avengers-endgame-4k-gv.jpg"
            alt="Second slide"
          />
      
          <Carousel.Caption>
            <h3>Captain America</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://hdqwalls.com/wallpapers/hulk-the-beast-4k-j0.jpg"
            alt="Third slide"
          />
      
          <Carousel.Caption>
            <h3 >Hulk</h3>
            <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
        </div>
    )
}

export default SliderComponent

