import React from 'react'
import {Table} from 'react-bootstrap'

function Tables() {
    return (
        <div>
            <Table striped bordered hover variant="dark"  className='m-5 p-2 text-warning'> 
  <thead>
    <tr>
      <th>#</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Username</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>Arnold</td>
      <td>Schwarzenegger</td>
      <td>@terminator</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Tommy</td>
      <td>Jones</td>
      <td>@smokey</td>
    </tr>
    <tr>
      <td>3</td>
      <td colSpan="2">Samuel L. Jackson</td>
      <td>@TheRaven</td>
    </tr>
  </tbody>
</Table>


        </div>
    )
}

export default Tables
